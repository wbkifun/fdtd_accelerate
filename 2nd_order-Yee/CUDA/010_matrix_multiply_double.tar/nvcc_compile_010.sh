#!/bin/sh

nvcc -arch=sm_13 010_matrix_multiply_double.cu -o 010_matrix_multiply_double.exe
